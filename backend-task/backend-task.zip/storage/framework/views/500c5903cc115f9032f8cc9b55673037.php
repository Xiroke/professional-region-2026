<?php $__env->startSection('body'); ?>
  <h2>Панель управления</h2>
  <h3 class="mt-4">Действия</h3>
  <div class="mt-2">
    <a href="<?php echo e(route('courses.index')); ?>" class="btn btn-primary btn-lg">Курсы</a>
    <a href="<?php echo e(route('students')); ?>" class="btn btn-primary btn-lg">Студенты</a>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\home\lr\prof-region-chel-2026\backend-task\resources\views/dashboard.blade.php ENDPATH**/ ?>