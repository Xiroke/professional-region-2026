@props(['route'])

<a href="{{$route}}" {{$attributes->class(['back'])}}><= Назад</a>